package com.example.finalapp.enumm;

public enum Status {
    Принят, Оформлен, Ожидает, Получен
}
