package com.example.finalapp.services;

import com.example.finalapp.models.Product;
import com.example.finalapp.models.Status;
import com.example.finalapp.repositories.StatusRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
public class StatusService {

    private final StatusRepository statusRepository;


    public StatusService(StatusRepository statusRepository) {
        this.statusRepository = statusRepository;



    }


    public List<Status> getAllStatus(){
        return statusRepository.findAll();
    }



}
