package com.example.finalapp.services;


import com.example.finalapp.enumm.Status;
import com.example.finalapp.models.Order;
import com.example.finalapp.models.Product;
import com.example.finalapp.repositories.OrderRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional(readOnly = true)
public class OrderService {


    private final OrderRepository orderRepository;


    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;

    }


    public List<Order> getAllOrder() {
        return orderRepository.findAll();
    }

    public Order getOrderId(int id) {
        Optional<Order> optionalProduct = orderRepository.findById(id);
        return optionalProduct.orElse(null);
    }

    @Transactional
    public void updateOrder(Order order, String result) {

        if (result.equals("Принят")){
            order.setStatus(Status.Принят);
            orderRepository.save(order);

        } else if  (result.equals("Оформлен")) {

            order.setStatus(Status.Оформлен);
            orderRepository.save(order);

        }else if  (result.equals("Ожидает")) {

            order.setStatus(Status.Ожидает);
            orderRepository.save(order);

        }else if  (result.equals("Получен")) {

            order.setStatus(Status.Получен);
            orderRepository.save(order);

        }


    }
}
